# Partner starter 1.0.0

接口演示包：静态 SVG、双语文字、独立响应式 HTML、固定画布 CSS 动画。所有资源离线，不读取设备或订单数据。

示例图标取自本项目提供的 Coffee Terminal 品牌图形，仅用于该品牌项目的接口示例。正式第三方交付须替换或确认素材、字体授权，并填写真实负责人及验收记录；此示例不提供对外商用授权声明。

交付内容：cover / message / editorial / motion。语言：zh-CN、en-US。参考画布1600×1100；HTML使用coffee.showcase.v1协议；动画响应paused和reducedMotion。

将本目录内容直接打包，manifest.json必须位于ZIP根目录。增加或修改正式发布内容时更新manifest.version；不得覆盖已安装版本。
